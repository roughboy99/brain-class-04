# Class 4 pre-class pack

Read `notes/CLASS-NOTES.md`, complete `PREWORK.md`, and use the slide deck for the
Telegram steps. The pack is designed to be shared before class and contains no
real credential values.

## Start here

1. Open `slides/class-04-telegram-integration.pptx` or the PDF copy.
2. Create and message a separate Brain bot.
3. Stop sharing your terminal and run `scripts/setup-telegram-private.sh`.
4. Follow `N8N-TELEGRAM-FIRST.md` (video 0 shows every click): add Telegram Trigger and
   create its credential. The token goes into a password field; never click the reveal icon.
5. Clear the clipboard and leave the workflow inactive.
6. Run `bash verify.sh` from your Class 2 stack.
7. Keep the included study workflow **inactive** until the live test gate passes.

## Contents

- `notes/CLASS-NOTES.md` — student-safe class notes and debugging order
- `notes/SESSION-WORKFLOW.md` — student-safe timeline, checkpoints and stop conditions
- `PREWORK.md` — readiness checklist
- `BUILD-THE-BOT.md` — full manual build reference
- `prompts/` — P1, P2, and P3 build prompts
- `workflow/09-voice-ask.UNVERIFIED.json` — inactive study workflow
- `setup-telegram-private.sh` — hidden-input secret setup and clipboard helper
- `PRIVATE-TELEGRAM-SETUP.md` — off-camera procedure
- `N8N-TELEGRAM-FIRST.md` — Step 0: trigger + credential, done before class and again live
- `verify.sh` and `VERIFY.md` — runtime checks and acceptance tests
- `CLAIMS-AUDIT.md` — claim evidence, corrections, and release gate
- `slides/` — screen-safe Telegram teaching deck
- `notes/TELEGRAM-SLIDE-NOTES.md` — presenter notes also embedded in the PPTX

## Security rule

Do not post `.class-04-private.env`, a BotFather token, a real owner ID, or an n8n
credential export. If a bot token leaks, use BotFather `/revoke` immediately.
